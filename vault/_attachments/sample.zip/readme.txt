Sample content for zip verification.
